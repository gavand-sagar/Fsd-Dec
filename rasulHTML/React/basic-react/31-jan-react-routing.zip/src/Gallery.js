import Header from "./Header";

export default function Gallery(){
    return (
        <div>
            <Header/>
            <h1>This is Gallery</h1>
        </div>
    )
}