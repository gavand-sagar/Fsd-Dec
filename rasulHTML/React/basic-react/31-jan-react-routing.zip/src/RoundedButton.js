export default function RoundedButton(props){
    return (
        <button className='my-button'>{props.label}</button>
    )
}