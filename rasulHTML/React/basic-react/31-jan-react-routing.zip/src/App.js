import { BrowserRouter, Link, Route, Routes } from "react-router-dom";
import About from "./About";
import "./App.css";
import Gallery from "./Gallery";
import Home from "./Home";
import PageNotFound from "./PageNotFound";
import Privacy from "./Privacy";

function App() {
  return (
    <div>
      <BrowserRouter>
        <Routes>
          <Route path="/home" element={<Home />}></Route>
          <Route path="/about" element={<About />}></Route>
          <Route path="/privacy" element={<Privacy />}></Route>
          <Route path="/gallery" element={<Gallery />}></Route>
          <Route path="/" element={<Home />}></Route>
          <Route path="/*" element={<PageNotFound />}></Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
