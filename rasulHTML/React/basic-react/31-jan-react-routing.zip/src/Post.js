import React from "react";

export default function Post({ heading, author, topic, time, content }) {
  return (
    <div className="post-container">
      <h2>{heading}</h2>
      <p>
        <span>By</span>
        <span>{author}</span>
        <span>|</span>
        <span>{topic}</span>
        <span>|</span>
        <span>{time}</span>
      </p>
      <p>{content}</p>
    </div>
  );
}
