import Header from "./Header";

export default function About(){
    return (
        <div>
            <Header/>
            <h1>This is About</h1>
        </div>
    )
}