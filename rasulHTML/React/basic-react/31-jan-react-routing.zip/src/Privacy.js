import Header from "./Header";

export default function Privacy(){
    return (
        <div>
            <Header/>
            <h1>This is Privacy</h1>
        </div>
    )
}