import Header from "./Header";


export default function Home(){
    return (
        <div>
            <Header/>
           
            <h1>This is home</h1>
        </div>
    )
}