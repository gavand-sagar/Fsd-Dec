import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Header from "./Header";
import Sagar from "./Sagar";
import Border from "./Border";
import SquareButton from "./SquareButton";
export default function Home() {
  const [page, setPage] = useState("");

  const navigate = useNavigate();

  function goToRoute() {
    navigate(page);
  }

  function submit() {
    alert(checked);
  }

  const [checked, setChecked] = useState(false);

  return (
    <div>
      <Header />

      <div className="container">
        <Border>
          <h1>sagar</h1>
        </Border>

        <h1>ekta</h1>

        <Border>
          <SquareButton label="some"></SquareButton>
        </Border>
        
        <SquareButton label="some"></SquareButton>
      </div>
    </div>
  );
}
