import React from 'react'

export default function Border({children}) {
  return (
    <div className="b">
       <label>ussjf </label>
       {children}
    </div>
  )
}
